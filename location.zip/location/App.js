import React, { useState, useEffect } from 'react';
import { Platform, Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';
import * as Location from 'expo-location';
import * as TaskManager from 'expo-task-manager';

export default function App() {
  const [location, setLocation] = useState(null);
  const [errorMsg, setErrorMsg] = useState(null);
  const [latitude, setLatitude] = useState(null);
  const [longitude, setLongitude] = useState(null);

  useEffect(() => {
    (async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();

      if (status !== 'granted') {
        setErrorMsg('Permission to access location was denied');
        return;
      }

      var Contador = 0;
      async function LocatAcces(locat) {
        var lat = locat.coords.latitude;
        var lon = locat.coords.longitude;
        setLatitude(lat);
        setLongitude(lon);
        alert(Contador);
        Contador++;
        setLocation(locat.coords);
      }

      const opcionesDeSolicitud = {
        acuracy: 'high',
        distanceInterval: 1
      };

      const ErrorDeUbic = (err) => {
        alert(err.code);
      };

      var ubicacion = await Location.watchPositionAsync(
        opcionesDeSolicitud,
        LocatAcces
      );

      

    })();
  }, []);

  function success() {}

  let text = 'Waiting..';
  if (errorMsg) {
    text = errorMsg;
  } else if (location) {
    text = JSON.stringify(location);
  }

  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>{latitude}</Text>
      <Text style={styles.paragraph}>{longitude}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#ffffff',
  },
  paragraph: {
    fontSize: 18,
    textAlign: 'center',
  },
});

export function watchPosition(
  LocatAcces: (locat: any) => void,
  ErrorDeUbic: (err: any) => void,
  opcionesDeSolicitud: {
    enableHighAccuracy: boolean,
    maximumAge: number,
    timeout: number,
  }
) {
  throw new Error('Function not implemented.');
}
